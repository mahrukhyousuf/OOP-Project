#include "lunch.hpp"

Lunch::Lunch() : Meals("Lunch") {}
