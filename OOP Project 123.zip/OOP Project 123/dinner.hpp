#pragma once
#include "meals.hpp"

class Dinner : public Meals {
public:
    Dinner();
};