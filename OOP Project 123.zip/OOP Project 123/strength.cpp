#include "strength.hpp"
Strength::Strength(std::string name, int sets, int reps, int weight)
        : FitnessChecker(name), numSets(sets), numReps(reps), weightUsed(weight) {}
void Strength:: calculateStrengthFitness() {
        // Assume a simple calculation based on sets, reps, and weight used
        int strengthScore = numSets * numReps * weightUsed;
        cout << "Strength Fitness Score for " << getUserName() << ": " << strengthScore << "\n";
    }
void Strength::displayFitnessStats() const {
        cout << "Strength Stats for " << getUserName() << ":\n";
        cout << "Sets: " << numSets << "\n";
        cout << "Reps: " << numReps << "\n";
        cout << "Weight Used: " << weightUsed << " units\n";
    }