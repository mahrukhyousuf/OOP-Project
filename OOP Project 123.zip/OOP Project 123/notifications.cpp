// #include "notifications.hpp"
// // Constructor
// Notification::Notification() {}

// // Method to add a notification
// void Notification::addNotification(const std::string& notification) {
//     notifications.push_back(notification);
// }

// // Method to display notifications
// void Notification::displayNotifications() const {
//     if (notifications.empty()) {
//         std::cout << "No notifications.\n";
//     } else {
//         std::cout << "Notifications:\n";
//         for (const auto& notification : notifications) {
//             std::cout << "- " << notification << "\n";
//         }
//     }
// }

