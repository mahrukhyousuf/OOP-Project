#include <iostream>
#include <string>
#include "user.hpp"
#include "fitnessgoals.hpp"
#include "cardio.hpp"
#include "strength.hpp"
#include "nutritionplan.hpp"

int main() {
    // Get user information
    std::string name;
    int age, tweight, tsteps, tcalories;
    double weight, height;
    char gender;

    std::cout << "Enter user information:\n";
    std::cout << "Name: ";
    std::getline(std::cin, name);

    std::cout << "Age: ";
    std::cin >> age;

    std::cout << "Weight (kg): ";
    std::cin >> weight;

    std::cout << "Height (cm): ";
    std::cin >> height;

    std::cout << "Gender (M/F): ";
    std::cin >> gender;

    std::cout << "Target weight: ";
    std::cin >> tweight;

    std::cout << "Target steps: ";
    std::cin >> tsteps;

    std::cout << "Target calories: ";
    std::cin >> tcalories;
    // Create a user
    FitnessGoals* fitnessgoals=  new FitnessGoals(tweight, tsteps, tcalories);
    User user(name, age, weight, height, gender, fitnessgoals);

    // Display user information
    user.displayUserInfo();

    // Display BMI
    std::cout << "BMI: " << user.getBMI() << "\n";

    // Display target heart rate
    std::cout << "Target Heart Rate: " << user.getTargetHeartRate() << "\n";

    // Create cardio and strength activities
    std::cout<<"CardioDuration: ";
    int cduration, ilevlel, s, r, w;
    cin>>cduration;
    std::cout<<"Intensity Level: ";
    cin>>ilevlel;
    Cardio cardioActivity(name, cduration, ilevlel);
    std::cout<<"\n"<<"Repetitions: ";
    std::cin>>r;
    std::cout<<"\n"<<"Sets: ";
    std::cin>>s;  
    std::cout<<"\n"<<"Weights Used: ";
    std::cin>>w;
    Strength strengthActivity(name, s, r, w);

    // Calculate and display fitness stats for cardio and strength activities
    cardioActivity.calculateCardioFitness();
    cardioActivity.displayFitnessStats();

    strengthActivity.calculateStrengthFitness();
    strengthActivity.displayFitnessStats();

    // Create a nutrition plan for the user
    NutritionPlan nutritionPlan(&user, fitnessgoals);

    // Generate and display the nutrition plan
    nutritionPlan.generateNutritionPlan();
    nutritionPlan.displayNutritionPlan();

    // Clean up dynamically allocated memory
    delete fitnessgoals;

    return 0;
}
