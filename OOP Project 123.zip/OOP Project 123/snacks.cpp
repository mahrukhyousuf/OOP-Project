#include "Snacks.hpp"

Snacks::Snacks() : Meals("Snacks") {}
