#include "cardio.hpp"
Cardio::Cardio(string name, int duration, int intensity)
        : FitnessChecker(name), cardioDuration(duration), intensityLevel(intensity) {}
void Cardio::calculateCardioFitness() {
        // Assume a simple calculation based on duration and intensity
        int cardioScore = cardioDuration * intensityLevel;
        cout << "Cardio Fitness Score for " << getUserName() << ": " << cardioScore << "\n";
    }

void Cardio::displayFitnessStats() const {
    cout << "Cardio Stats for " << getUserName() << ":\n";
    cout << "Duration: " << cardioDuration << " minutes\n";
    cout << "Intensity: " << intensityLevel << "/10\n";  // Out of 10
}