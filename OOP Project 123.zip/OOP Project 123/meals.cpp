#include "meals.hpp"
#include <libxl.h>
using namespace libxl;

Meals::Meals(const std::string& cat): category(cat), totalCalories(0) {}

void Meals::calculateTotalCalories(Book* book) {
    Sheet* sheet = book->getSheet(0);

    if (sheet) {
        int rows = sheet->lastRow();
        for (int i = 0; i < rows; ++i) {
            if (sheet->readStr(i, 0) == category) {
                int calories = sheet->readNum(i, 1);
                totalCalories += calories;
            }
        }
    }
}

string Meals::getCategory() const {
    return Meals::category;
}

int Meals::getTargetCalories() const {
    return Meals::targetCalories;
}

int Meals::getTotalCalories() const {
    return Meals::totalCalories;
}

int Meals::setTargetCalories(int targetCalories) {
    Meals::targetCalories = targetCalories;
}
