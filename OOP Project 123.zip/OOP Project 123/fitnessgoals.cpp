#include "fitnessgoals.hpp"
    // Default constructor
    FitnessGoals::FitnessGoals()
        : targetWeight(0), targetSteps(0), targetCalories(0) {}

    // Parameterized constructor
    FitnessGoals::FitnessGoals(int weight, int steps, int calories)
        : targetWeight(weight), targetSteps(steps), targetCalories(calories) {}

    // Methods to set fitness goals
    void FitnessGoals:: setTargetWeight(int weight) {
        targetWeight = weight;
    }

    void FitnessGoals:: setTargetSteps(int steps) {
        targetSteps = steps;
    }

    void FitnessGoals:: setTargetCalories(int calories) {
        targetCalories = calories;
    }

    // Methods to retrieve fitness goals
    int FitnessGoals:: getTargetWeight() const {
        return targetWeight;
    }

    int FitnessGoals::getTargetSteps() const {
        return targetSteps;
    }

    int FitnessGoals:: getTargetCalories() const {
        return targetCalories;
    }

    // Display fitness goals
    void FitnessGoals:: displayFitnessGoals() const {
        cout << "Fitness Goals:\n";
        cout << "Target Weight: " << targetWeight << " kg\n";
        cout << "Target Daily Steps: " << targetSteps << "\n";
        cout << "Target Daily Calories: " << targetCalories << " kcal\n";
    }
