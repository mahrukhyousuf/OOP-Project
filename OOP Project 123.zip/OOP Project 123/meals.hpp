
#pragma once
#include <iostream>
#include <libxl.h>
using namespace std;

class Meals {
protected:
    std::string category;
    int totalCalories;
    int targetCalories;

public:
    Meals(const std::string& cat);
    void calculateTotalCalories(libxl::Book* book);
    int getTotalCalories() const;
    string getCategory() const;
    int getTargetCalories() const;
    int setTargetCalories(int targetCalories);
};
