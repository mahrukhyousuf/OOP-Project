#include "healthmetrics.hpp"

HealthMetrics::HealthMetrics(int heartRate, int bloodPressure, int sleepDuration, const std::string& date)
    : heartRate(heartRate), bloodPressure(bloodPressure), sleepDuration(sleepDuration) {}


int HealthMetrics:: getHeartRate() const { return heartRate; }
int HealthMetrics:: getBloodPressure() const { return bloodPressure; }
int HealthMetrics:: getSleepDuration() const { return sleepDuration; }



