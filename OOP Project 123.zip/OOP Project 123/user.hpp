#pragma once
#include <iostream>
#include <string>
#include <vector>
#include "fitnessutility.hpp"
#include "fitnessgoals.hpp"

using namespace std;

class User {
private:
    string name;
    int age;
    double weight;
    double height;
    char gender;
    FitnessGoals* fitnessGoals;

public:
    User(string n, int a, double w, double h, char g, FitnessGoals* fg);
    void displayUserInfo();
    double getBMI();
    double getTargetHeartRate();
    double getEstimatedCalorieBurn(int durationInMinutes, char activityLevel);
    string getName() const;
};
