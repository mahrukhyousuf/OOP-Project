#include "nutritionplan.hpp"
#include "meals.hpp"
#include "lunch.hpp"
#include "breakfast.hpp"
#include "dinner.hpp"
#include "snacks.hpp"
#include <libxl.h>

using namespace libxl;

NutritionPlan::NutritionPlan(User* u, FitnessGoals* fg) : user(u), fitnessGoals(fg) {}

NutritionPlan::~NutritionPlan() {
    for (auto& meal : meals) {
        delete meal;
    }
}

void NutritionPlan::generateNutritionPlan() {
    Book* book = xlCreateBook();
    if (book->load("meals_data.xlsx")) {
        // Initialize meal categories
        Breakfast* breakfast = new Breakfast();
        Lunch* lunch = new Lunch();
        Dinner* dinner = new Dinner();
        Snacks* snacks = new Snacks();

        // Calculate total calories for each meal category
        breakfast->calculateTotalCalories(book);
        lunch->calculateTotalCalories(book);
        dinner->calculateTotalCalories(book);
        snacks->calculateTotalCalories(book);

        // Add meals to the vector
        meals.push_back(breakfast);
        meals.push_back(lunch);
        meals.push_back(dinner);
        meals.push_back(snacks);

        // Clean up Excel book
        book->release();
    } else {
        cerr << "Error: Failed to load meals data from Excel.\n";
        delete book;
        return;
    }

    // Logic to generate the nutrition plan based on fitness goals and meal categories
    int targetCalories = fitnessGoals->getTargetCalories();
    double calorieDistributionFactor = 0.25;

    // Calculate target calories for each meal category
    int breakfastTargetCalories = static_cast<int>(targetCalories * calorieDistributionFactor);
    int lunchTargetCalories = static_cast<int>(targetCalories * calorieDistributionFactor);
    int dinnerTargetCalories = static_cast<int>(targetCalories * calorieDistributionFactor);
    int snacksTargetCalories = targetCalories - (breakfastTargetCalories + lunchTargetCalories + dinnerTargetCalories);

    // Set target calories for each meal category
    meals[0]->setTargetCalories(breakfastTargetCalories);
    meals[1]->setTargetCalories(lunchTargetCalories);
    meals[2]->setTargetCalories(dinnerTargetCalories);
    meals[3]->setTargetCalories(snacksTargetCalories);

    // Suggest meals based on available options
    for (const auto& meal : meals) {
        string category = meal->getCategory();
        int targetCalories = meal->getTargetCalories();

        cout << "Suggestions for " << category << " (" << targetCalories << " kcal):\n";

        // Load Excel data again to get food names and their calories
        Book* suggestionBook = xlCreateBook();
        if (suggestionBook->load("meals_data.xlsx")) {
            Sheet* sheet = suggestionBook->getSheet(0);
            if (sheet) {
                int rows = sheet->lastRow();
                for (int i = 0; i < rows; ++i) {
                    if (sheet->readStr(i, 0) == category) {
                        string foodName = sheet->readStr(i, 0);
                        int calories = sheet->readNum(i, 1);

                        // Suggest the food if it's close to the target calories
                        if (abs(calories - targetCalories) < 50) {
                            cout << "- " << foodName << " (" << calories << " kcal)\n";
                        }
                    }
                }
            }
            suggestionBook->release();
        } else {
            cerr << "Error: Failed to load meals data for suggestions.\n";
            delete suggestionBook;
            return;
        }

        cout << "\n";
    }
}

void NutritionPlan::displayNutritionPlan() const {
    cout << "Generated Nutrition Plan for " << user->getName() << ":\n";
    user->displayUserInfo();
    fitnessGoals->displayFitnessGoals();

    for (const auto& meal : meals) {
        cout << meal->getCategory() << " - Target Calories: " << meal->getTargetCalories() << " kcal\n";
    }
}
