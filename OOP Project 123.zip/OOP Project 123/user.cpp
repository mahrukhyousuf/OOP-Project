#include "user.hpp"
#include "fitnessutility.hpp"
User::User(string n, int a, double w, double h, char g, FitnessGoals* fg)
    : name(n), age(a), weight(w), height(h), gender(g), fitnessGoals(fg) {}

void User::displayUserInfo() {
    cout << "User Information:\n";
    cout << "Name: " << name << "\n";
    cout << "Age: " << age << "\n";
    cout << "Gender: " << gender << "\n";
    cout << "Weight: " << weight << " kg\n";
    cout << "Height: " << height << " cm\n";
}

double User::getBMI() {
    FitnessUtility utility;
    return utility.calculateBMI(weight, height);
}

double User::getTargetHeartRate() {
    FitnessUtility utility;
    return utility.calculateTargetHeartRate(age, gender);
}

double User::getEstimatedCalorieBurn(int durationInMinutes, char activityLevel) {
    FitnessUtility utility;
    return utility.estimateCalorieBurn(weight, durationInMinutes, activityLevel);
}

string User::getName() const{
	return User::name;
}
