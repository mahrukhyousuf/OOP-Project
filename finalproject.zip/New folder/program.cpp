#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>

using namespace std;
float calculatedCalories;  // Move to global scope
int fitnessLevel;          // Move to global scope
bool hasEquipment;          // Move to global scope

person ki class:
// Define a class representing an individual person's information
class Person {
public:
    string name;
    float height, weight;
    int age;  // Add age as a member
    int gender;  // Add gender as a member
	float bmi;
	int fitnessLevel;    // Add this line
    bool hasEquipment; 

    // Method to input personal information
    void input() {
        fflush(stdin);  // Clear input buffer
        cout << "Enter Your Name: ";
        cin >> name;
        cout << "Enter Your Age: ";
        cin >> age;  // Add age input
        cout << "Enter Your Gender (1 for Male, 2 for Female): ";
        cin >> gender;  // Add gender input
        cout << "Enter Your Height (in meters): ";
        cin >> height;
        cout << "Enter Your Weight (in Kg): ";
        cin >> weight;
    }

    // Method to print health report
    void print() {
        ofstream file("Health_Report.txt", ios::app);  // Open a file to write
        file << "____________________________" << endl;
        file << "       Health Advisor       " << endl;
        file << "____________________________" << endl;
        file << "NAME : " << setw(5) << name << endl;
        file << "AGE : " << age << " years" << endl;  // Print age
        file << "GENDER : " << (gender == 1 ? "Male" : "Female") << endl;  // Print gender
        file << "HEIGHT : " << height << " Meters" << endl;
        file << "WEIGHT : " << weight << " Kg" << endl;
        file.close();  // Close the file
    }
};


feedback ki class commented:
// Class that provides feedback based on BMI
class Feedback {
public:
    // Method to provide BMI feedback
    void provideFeedback(float bmi) {
        cout << "------------------------------------" << endl;  // Visual separator
        cout << "            BMI Feedback             " << endl;  // Title for BMI feedback
        cout << "------------------------------------" << endl;  // Visual separator

        // Check various BMI ranges and provide corresponding feedback
        if (bmi < 18.5) {
            cout << "BMI Category: Underweight" << endl;  // Category for underweight BMI
            cout << "Feedback: You are underweight. Consider gaining some weight for a healthier BMI." << endl;  // Feedback for underweight
        } else if (bmi >= 18.5 && bmi < 25.0) {
            cout << "BMI Category: Normal Weight" << endl;  // Category for normal BMI
            cout << "Feedback: Congratulations! Your BMI is in the healthy range." << endl;  // Feedback for normal BMI
        } else if (bmi >= 25.0 && bmi < 30.0) {
            cout << "BMI Category: Overweight" << endl;  // Category for overweight BMI
            cout << "Feedback: Pay attention! You are overweight. Consider adopting a healthier lifestyle." << endl;  // Feedback for overweight
        } else {
            cout << "BMI Category: Obese" << endl;  // Category for obese BMI
            cout << "Feedback: Warning! You are in the obese range. Consult with a healthcare professional for guidance." << endl;  // Feedback for obese
        }

        cout << "------------------------------------" << endl;  // Closing visual separator
    }
};


// Class that calculates calorie requirements
class CalorieCalculator {
public:
    float calculatedCalories;  // Variable to hold calculated calories

    // Method to calculate daily calorie needs based on given parameters
    void calculateCalories(int age, int gender, float height, float weight) {
        // Placeholder logic for calorie calculation (using BMR formula)
        float basalMetabolicRate = 0;

        // Formulae for Basal Metabolic Rate calculation based on gender
        if (gender == 1) { // Assuming 1 for male, 2 for female
            basalMetabolicRate = 88.362 + (13.397 * weight) + (4.799 * height * 100) - (5.677 * age);
        } else if (gender == 2) {
            basalMetabolicRate = 447.593 + (9.247 * weight) + (3.098 * height * 100) - (4.330 * age);
        }

        // Display calculated calorie needs per day
        std::cout << "Calories calculated: " << basalMetabolicRate << " calories per day." << std::endl;
    }
};

bmi diet plan and diet generator code:
// Class for BMI calculations
class BMI {
public:
    // Method to calculate BMI based on height and weight
    float calculateBMI(float height, float weight) {
        float x = height * height;  // Calculate square of height
        return weight / x;  // Calculate BMI using weight divided by square of height
    }

    // Method to check BMI and provide feedback
    void checkBMI(Person& person, Feedback& feedback) {
        float bmi = calculateBMI(person.height, person.weight);  // Calculate BMI for the given person
        feedback.provideFeedback(bmi);  // Provide BMI feedback using the Feedback class

        // Save a report with person's details
        person.print();
    }
};

#include <iostream>

// Class for recommending diets based on BMI
class DietRecommendation {
public:
    // Method to recommend diet based on BMI
    void recommendDiet(float bmi) {
        std::cout << "------------------------------------" << std::endl;  // Visual separator
        std::cout << "        Diet Recommendation         " << std::endl;  // Title for diet recommendation
        std::cout << "------------------------------------" << std::endl;  // Visual separator

        // Based on BMI ranges, recommend appropriate diet plans
        if (bmi < 18.5) {
            std::cout << "Recommendation: You are underweight. Consider a diet with nutrient-rich foods to gain weight." << std::endl;  // Diet recommendation for underweight
        } else if (bmi >= 18.5 && bmi < 25.0) {
            std::cout << "Recommendation: Your BMI is in the healthy range. Maintain a balanced diet for overall well-being." << std::endl;  // Diet recommendation for normal BMI
        } else if (bmi >= 25.0 && bmi < 30.0) {
            std::cout << "Recommendation: You are overweight. Consider a balanced diet and regular exercise to achieve a healthy weight." << std::endl;  // Diet recommendation for overweight
        } else {
            std::cout << "Recommendation: You are in the obese range. Consult with a healthcare professional for personalized diet advice." << std::endl;  // Diet recommendation for obese
        }

        std::cout << "------------------------------------" << std::endl;  // Closing visual separator
    }
};

#include <iostream>

// Class for generating diet plans based on daily calorie requirements
class DietPlanGenerator {
public:
    // Method to generate a diet plan based on daily calorie requirements
    void generateDietPlan(float dailyCalories) {
        std::cout << "------------------------------------" << std::endl;  // Visual separator
        std::cout << "         Diet Plan Generator         " << std::endl;  // Title for diet plan generator
        std::cout << "------------------------------------" << std::endl;  // Visual separator

        // Presents a diet plan based on different calorie ranges

        std::cout << "Your Diet Plan for the Day:" << std::endl;  // Indicate the beginning of the diet plan

        // Diet plan variations based on daily calorie needs
        if (dailyCalories < 1500) {
            // Diet plan for fewer than 1500 calories
        } else if (dailyCalories >= 1500 && dailyCalories < 2000) {
            // Diet plan for 1500-2000 calories
        } else {
            // Diet plan for more than 2000 calories
        }

        std::cout << "------------------------------------" << std::endl;  // Closing visual separator
    }
};



#include <iostream>

exercise suggester:
// Define a class for suggesting exercises
class ExerciseSuggester {
public:
    // Method to suggest exercises based on fitness level and equipment availability
    void suggestExercise(int fitnessLevel, bool hasEquipment) {
        // Display a separator and title for exercise suggestions
        std::cout << "------------------------------------" << std::endl;
        std::cout << "         Exercise Suggester          " << std::endl;
        std::cout << "------------------------------------" << std::endl;

        // Placeholder logic for suggesting exercises based on preferences
        // Replace this with an actual exercise suggestion algorithm

        // Display the message indicating recommended exercises
        std::cout << "Recommended Exercises:" << std::endl;

        // Check fitness levels and suggest exercises accordingly
        if (fitnessLevel == 1) {
            std::cout << "- Brisk walking or jogging" << std::endl;
            std::cout << "- Bodyweight exercises (e.g., push-ups, squats)" << std::endl;
            std::cout << "- Beginner-level yoga" << std::endl;
        } else if (fitnessLevel == 2) {
            std::cout << "- Running or cycling" << std::endl;
            std::cout << "- Strength training with dumbbells or resistance bands" << std::endl;
            std::cout << "- Intermediate-level yoga or pilates" << std::endl;
        } else {
            std::cout << "- High-intensity interval training (HIIT)" << std::endl;
            std::cout << "- Advanced strength training with gym equipment" << std::endl;
            std::cout << "- Advanced yoga or pilates" << std::endl;
        }

        // Check equipment availability and suggest exercises accordingly
        if (hasEquipment) {
            std::cout << "- Incorporate gym equipment for a more challenging workout." << std::endl;
        } else {
            std::cout << "- No equipment needed. Bodyweight exercises can be effective." << std::endl;
        }

        // Display a closing separator
        std::cout << "------------------------------------" << std::endl;
    }
};
#include <iostream>
#include <vector>

// Define a class for managing exercise schedules
class ExerciseSchedule {
public:
    // Define a structure to hold exercise name and time
    struct Exercise {
        std::string name;
        std::string time;

        // Constructor initializing exercise name and time
        Exercise(const std::string& n, const std::string& t) : name(n), time(t) {}
    };

private:
    std::vector<Exercise> schedule; // Container to store scheduled exercises

public:
    // Method to add an exercise to the schedule
    void addExercise(const std::string& exerciseName, const std::string& exerciseTime) {
        schedule.emplace_back(exerciseName, exerciseTime);
    }

    // Method to display the exercise schedule
    void displaySchedule() const {
        // Display a separator and title for the exercise schedule
        std::cout << "------------------------------------" << std::endl;
        std::cout << "          Exercise Schedule          " << std::endl;
        std::cout << "------------------------------------" << std::endl;

        // Check if the schedule is empty and output a message accordingly
        if (schedule.empty()) {
            std::cout << "No exercises scheduled." << std::endl;
        } else {
            std::cout << "Scheduled Exercises:" << std::endl;

            // Iterate through scheduled exercises and display their names and times
            for (const auto& exercise : schedule) {
                std::cout << "- " << exercise.name << " at " << exercise.time << std::endl;
            }
        }

        // Display a closing separator
        std::cout << "------------------------------------" << std::endl;
    }

    // Method to create the exercise schedule based on fitness levels
    void createExerciseSchedule();
};

// Method to generate an exercise schedule based on fitness levels
void ExerciseSchedule::createExerciseSchedule() {
    // Clear any existing schedule
    schedule.clear();

    // Define a set of exercises based on fitness levels
    std::vector<std::string> exercises;

    // Logic to select exercises based on fitness level
    if (fitnessLevel == 1) {
        exercises = {"Brisk walking or jogging", "Bodyweight exercises", "Beginner-level yoga"};
    } else if (fitnessLevel == 2) {
        exercises = {"Running or cycling", "Strength training", "Intermediate-level yoga or pilates"};
    } else {
        exercises = {"High-intensity interval training (HIIT)", "Advanced strength training", "Advanced yoga or pilates"};
    }

    // Assign times of the day to exercises (example: morning, afternoon, evening)
    std::vector<std::string> exerciseTimes = {"Morning", "Afternoon", "Evening"};

    // Add exercises to the schedule with assigned times
    for (size_t i = 0; i < exercises.size(); ++i) {
        addExercise(exercises[i], exerciseTimes[i % exerciseTimes.size()]);
    }

    // Display the generated exercise schedule
    displaySchedule();
}


#include <iostream>
#include <fstream>
#include <string>

class ReportWriter {
public:
    // Method to write a health report to a file
    void writeReport(const std::string& content) {
        // Open the file "Health_Report.txt" in append mode
        std::ofstream file("Health_Report.txt", std::ios::app);

        // Write the provided content to the file
        file << content << std::endl;

        // Close the file
        file.close();
    }
};

#include <iostream>
#include <fstream>
#include <string>

class HealthReport {
public:
    std::string reportContent; // String to store the content of the health report

    // Method to view an existing health report
    void viewReport() const {
        if (reportContent.empty()) {
            // If no report content exists, display a message indicating its absence
            std::cout << "No health report available." << std::endl;
        } else {
            // If the report content exists, display the report content within a formatted boundary
            std::cout << "------------------------------------" << std::endl;
            std::cout << "           Health Report             " << std::endl;
            std::cout << "------------------------------------" << std::endl;
            std::cout << reportContent << std::endl;
            std::cout << "------------------------------------" << std::endl;
        }
    }

    // Method to load a health report from a file
    void loadReportFromFile(const std::string& fileName) {
        // Open the specified file
        std::ifstream file(fileName);
        if (file.is_open()) {
            std::string line;

            // Read each line of the file and append it to the report content string
            while (getline(file, line)) {
                reportContent += line + "\n";
            }

            // Close the file once all content is read
            file.close();
        } else {
            // Display an error message if the file couldn't be opened
            std::cout << "Error: Unable to open the health report file." << std::endl;
        }
    }
};

// Class to calculate BMI
class BMICalculator {
public:
    BMI bmi; // BMI object

    // Method to start BMI calculation for a person
    void startBMI(Person& person, Feedback& feedback) {
        person.input(); // Input person's details
        bmi.checkBMI(person, feedback); // Check BMI based on the input
    }
};

// Class to plan a diet based on a person's details
class DietPlanner {
public:
    CalorieCalculator calorieCalculator; // Calorie calculator object
    DietPlanGenerator dietPlanGenerator; // Diet plan generator object
    DietRecommendation dietRecommendation; // Diet recommendation object
    ReportWriter reportWriter; // Report writer object

    // Method to start planning a diet for a person
    void startDietPlan(Person& person) {
        person.input(); // Input person's details
        calorieCalculator.calculateCalories(person.age, person.gender, person.height, person.weight); // Calculate calories based on input
        calculatedCalories = calorieCalculator.calculatedCalories; // Assign calculated calories to a global variable

        dietRecommendation.recommendDiet(person.bmi); // Recommend a diet based on person's BMI
        dietPlanGenerator.generateDietPlan(calculatedCalories); // Generate a diet plan based on calculated calories
        // person.print(); // Uncomment if needed to print person's details
        // reportWriter.writeReport("Additional diet recommendations..."); // Uncomment if needed to write additional diet recommendations to a report
    }
};

// Class to plan exercises based on a person's fitness level and equipment availability
class ExercisePlanner {
public:
    ExerciseSuggester exerciseSuggester; // Exercise suggester object
    ExerciseSchedule exerciseSchedule; // Exercise schedule object
    ReportWriter reportWriter; // Report writer object

    // Method to start planning exercises for a person
    void startExercisePlan(Person& person) {
        person.input(); // Input person's details
        exerciseSuggester.suggestExercise(person.fitnessLevel, person.hasEquipment); // Suggest exercises based on fitness level and equipment availability

        // Generate an exercise schedule based on fitness level and equipment availability
        exerciseSchedule.createExerciseSchedule();

        }
};

// Class to view a health report
class ReportViewer {
public:
    HealthReport healthReport; // Health report object

    // Method to start viewing a health report
    void startViewer() {
        healthReport.viewReport(); // View the health report
    }
};


int main() {
    int choice;

    // Display the welcome message
    cout << "Welcome to AV's Fitness Advisor" << endl;

    // Start a do-while loop to repeatedly display the menu until the user chooses to exit
    do {
        // Display the menu options
        cout << "1. BMI Calculator" << endl;
        cout << "2. Diet Plan" << endl;
        cout << "3. Exercise Plan" << endl;
        cout << "4. View Last Report" << endl;
        cout << "5. Exit" << endl;
        cout << "Enter your choice: ";

        // Get the user's choice
        cin >> choice;

        // Create instances of various classes needed for different functionalities
        Person person;
        Feedback feedback;
        BMI bmiCalculator;
        CalorieCalculator calorieCalculator;
        DietPlanGenerator dietPlanGenerator;
        DietRecommendation dietRecommendation;
        ExerciseSuggester exerciseSuggester;
        ExerciseSchedule exerciseSchedule;
        ReportWriter reportWriter;
        ReportViewer reportViewer;
        BMICalculator bmiManager;
        DietPlanner dietPlanner;
        ExercisePlanner exercisePlanner;

        // Use a switch statement to perform actions based on the user's choice
        switch (choice) {
            case 1:
                // Execute BMI calculation functionality
                bmiManager.startBMI(person, feedback);
                break;
            case 2:
                // Execute diet planning functionality
                dietPlanner.startDietPlan(person);
                break;
            case 3:
                // Execute exercise planning functionality
                exercisePlanner.startExercisePlan(person);
                break;
            case 4:
                // View the last health report
                reportViewer.startViewer();
                break;
            case 5:
                // Display an exit message
                cout << "Exiting the program." << endl;
                break;
            default:
                // Display an error message for an invalid choice
                cout << "Invalid choice. Please enter a valid option." << endl;
        }

    } while (choice != 5);  // Continue the loop until the user chooses to exit

    return 0;  // Return 0 to indicate successful program execution
}