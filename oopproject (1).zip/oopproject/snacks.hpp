
#pragma once
#include "meals.hpp"

class Snacks : public Meals {
public:
    Snacks();
};