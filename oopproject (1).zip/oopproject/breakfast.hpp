#pragma once
#include "meals.hpp"

class Breakfast : public Meals {
public:
    Breakfast();
};