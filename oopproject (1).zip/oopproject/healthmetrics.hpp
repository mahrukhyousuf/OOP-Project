#pragma once
#include <iostream>
using namespace std;
class HealthMetrics {
private:
    int heartRate;
    int bloodPressure;
    int sleepDuration;
    // Add other health metrics attributes as needed

public:
    HealthMetrics(int heartRate, int bloodPressure, int sleepDuration, const std::string& date);

    // Getter methods
    int getHeartRate() const ;
    int getBloodPressure() const;
    int getSleepDuration() const;

};