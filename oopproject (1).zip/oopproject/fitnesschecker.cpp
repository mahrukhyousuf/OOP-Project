#include "fitnesschecker.hpp"
FitnessChecker::FitnessChecker(string name) : userName(name) {}
const string& FitnessChecker::getUserName() const {
        return userName;
    }