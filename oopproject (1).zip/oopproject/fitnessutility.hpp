#pragma once
#include <iostream>
using namespace std;


class FitnessUtility {

    public:
    double calculateBMI(double weight, double height);
    double calculateTargetHeartRate(int age, char gender);
    double estimateCalorieBurn(double weight, int durationInMinutes, char activityLevel);
};