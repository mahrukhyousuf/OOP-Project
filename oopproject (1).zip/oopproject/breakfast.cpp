#include "breakfast.hpp"

Breakfast::Breakfast() : Meals("Breakfast") {}
