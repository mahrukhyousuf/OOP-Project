#pragma once
#include <iostream>
#include <vector>
#include <libxl.h>
#include "user.hpp"
#include "fitnessgoals.hpp"
#include "meals.hpp"


using namespace std;
using namespace libxl;

class NutritionPlan {
private:
    User* user;
    FitnessGoals* fitnessGoals;
    vector<Meals*> meals;

public:
    NutritionPlan(User* u, FitnessGoals* fg);
    ~NutritionPlan();
    void generateNutritionPlan();
    void displayNutritionPlan() const;
};