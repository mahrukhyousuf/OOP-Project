#pragma once
#include "fitnesschecker.hpp"
class Cardio : public FitnessChecker {
private:
    int cardioDuration; // minutes
    int intensityLevel; //  from 1 to 10

public:
    Cardio(string name, int duration, int intensity);

    void calculateCardioFitness() ;

    void displayFitnessStats() const override ;
};


