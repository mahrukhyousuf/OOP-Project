
#pragma once
#include <iostream>
#include <libxl.h>
using namespace std;

class Meals {
protected:
    std::string category;
    int totalCalories;

public:
    Meals(const std::string& cat);
    void calculateTotalCalories(Book* book);
    int getTotalCalories() const;
};
