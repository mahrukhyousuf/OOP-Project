#include "dinner.hpp"

Dinner::Dinner() : Meals("Dinner") {}
