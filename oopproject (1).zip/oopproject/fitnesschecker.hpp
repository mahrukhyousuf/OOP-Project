// Fitness Check - abstract class base class
#pragma once
#include <iostream>
#include <string>
using namespace std;

class FitnessChecker {
protected:
    string userName;

public:
    FitnessChecker(string name);

    virtual void displayFitnessStats() const = 0; //  purevirtual func

    const string& getUserName() const ;
};

