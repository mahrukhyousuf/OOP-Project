#include "fitnesschecker.hpp"
class Strength : public FitnessChecker {
private:
    int numSets;
    int numReps;
    int weightUsed;

public:
    Strength(std::string name, int sets, int reps, int weight);
    void calculateStrengthFitness();
    void displayFitnessStats() const override ;
};