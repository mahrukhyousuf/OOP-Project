
#pragma once
#include "meals.hpp"

class Lunch : public Meals {
public:
    Lunch();
};