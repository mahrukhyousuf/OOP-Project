#include "meals.hpp"


Meals::Meals(const std::string& cat): category(cat), totalCalories(0) {}

void Meals::calculateTotalCalories(Book* book) {
    Sheet* sheet = book->getSheet(0);

    if (sheet) {
        int rows = sheet->lastRow();
        for (int i = 0; i < rows; ++i) {
            if (sheet->readStr(i, 0) == category) {
                int calories = sheet->readNum(i, 1);
                totalCalories += calories;
            }
        }
    }
}

int Meals::getTotalCalories() const {
    return totalCalories;
}
