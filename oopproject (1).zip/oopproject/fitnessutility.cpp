#include "fitnessutility.hpp"

// Function to calculate BMI
double FitnessUtility::calculateBMI(double weight, double height){
    if (height == 0) {
        std::cerr << "Error: Height cannot be zero for BMI calculation.\n";
        
    }
    // BMI formula: weight (kg) / (height (m) * height (m))
    return  weight / (height * height);
}

// Function to estimate target heart rate
double FitnessUtility::calculateTargetHeartRate(int age, char gender) {
    // Basic formula, may need adjustments based on fitness guidelines
    // For example: 220 - age to estimate maximum heart rate
    int maxHeartRate = 220 - age;

    // Adjust max heart rate based on gender
    if (gender == 'M' || gender == 'm') {
        return  (0.7 * maxHeartRate);
    } else if (gender == 'F' || gender == 'f') {
        return (0.75 * maxHeartRate);
    } else {
        std::cerr << "Error: Invalid gender for target heart rate calculation.\n";
        
    }
}

// Static function to estimate calorie burn

double FitnessUtility::estimateCalorieBurn(double weight, int durationInMinutes, char activityLevel) {
    // durationInMinutes is the time spent by user engaging in a particular physical activity
    // activityLevel is intensity level of the activity, represented by char:
    // 'S' (or 's'): Sedentary or light activity
    // 'L' (or 'l'): Light activity
    // 'M' (or 'm'): Moderate activity
    // 'V' (or 'v'): Vigorous activity
    // Basic formula, may need adjustments based on fitness guidelines
    // For example: weight (kg) * MET value * duration (hours)
    // MET (Metabolic Equivalent of Task) is a measure of the energy cost of an activity
    double metValue = 0.0;

    switch (activityLevel) {
        case 'S': // Sedentary
            metValue = 1.2;
            break;
        case 'L': // Light activity
            metValue = 1.5;
            break;
        case 'M': // Moderate activity
            metValue = 3.0;
            break;
        case 'V': // Vigorous activity
            metValue = 6.0;
            break;
        default:
            cerr << "Error: Invalid activity level for calorie burn estimation.\n";
            break;
    }

    // Convert duration to hours
    double durationInHours = durationInMinutes / 60.0;

    // Calculate calorie burn
    return weight * metValue * durationInHours;
}
