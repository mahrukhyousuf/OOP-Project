// #include <iostream>
// #include <vector>

// class Notification {
// private:
//     std::vector<std::string> notifications;

// public:
//     Notification();
//     void addNotification(const std::string& notification) ;
//     void displayNotifications() const ;
// };