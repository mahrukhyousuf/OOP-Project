#pragma once
#include <iostream>
using namespace std;

class FitnessGoals {
private:
    int targetWeight;  // Target weight in kilograms
    int targetSteps;    // Target daily steps
    int targetCalories; // Target daily calorie intake

public:
    FitnessGoals();
    FitnessGoals(int weight, int steps, int calories);
    void setTargetWeight(int weight);
    void setTargetSteps(int steps);
    void setTargetCalories(int calories);
    int getTargetWeight() const ;
    int getTargetSteps() const;
    int getTargetCalories() const;
    void displayFitnessGoals() const ;
};